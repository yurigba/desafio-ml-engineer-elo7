# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name="model_inference",
    version="0.1",
    description="Micro-package `model_inference`",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
)
